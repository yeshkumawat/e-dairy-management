import datetime

def greet_user():
    # Get current time
    current_time = datetime.datetime.now().time()

    # Extract hour and minute
    hour = current_time.hour
    minute = current_time.minute

    # Greeting based on time
    if 6 <= hour < 12:
        return 'Good morning.'
    elif 12 <= hour < 18:
        return 'Good afternoon.'
    elif 18 <= hour < 22:
        return 'Good evening.'
    else:
        return 'Good night.'

# Call the function to get the appropriate greeting
greeting = greet_user()
print(greeting)
